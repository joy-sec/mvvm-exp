package com.paperflybd.com.niceproject.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;

public class MainActivityViewModel extends AndroidViewModel {



    public MainActivityViewModel(@NonNull Application application) {
        super(application);
    }
}
